# TeaLovingLadMOP
MOP (Mouths o' Plenty) adds around 100 mouths for your characters to yap with!

This mod offers smiles and snarls, playful and serious, jokes and more!

![alt text](https://imgur.com/awJpou0.png)

![alt text](https://imgur.com/BserEgN.png)
